
CREATE DATABASE humanresources;
USE humanresources ;

CREATE TABLE Employee (
    EmpNo VARCHAR(10) PRIMARY KEY,
    Ename VARCHAR(30),
    Job VARCHAR(30),
    Salary INT,
    DeptNo INT
);

INSERT INTO Employee (EmpNo, Ename, Job, Salary, DeptNo)
VALUES
('E001', NULL,     'Clerk',     40000, 20),
('E002', 'Agaba',  'Manager',   16000, 30),
('E003', 'Mary',   'SalesLady', 20000, 20),
('E004', 'Timo',   'Clerk',     40000, 30),
('E005', 'Simon',  'Manager',   60000, 40),
('E006', 'Mark',   'Manager',   45000, 10),
('E007', 'Solomon','Teacher',    30000, 30);

select * from employee;
CREATE view viewB as select * from  Employee where Ename like 'DON<>20';
CREATE view viewC as select * from  Employee where Salary BETWEEN 40000,60000;
CREATE view viewD as select sum(salary) as Spent_on_managers,COUNT(*) as number_of_managers,max(salary) as Atmost_paid_manager from Employee where job='manager';
CREATE view viewE as select salary,DeptNo from employee ORDER BY EmpNo desc LIMIT 2;
CREATE view viewF as select * from  Employee where Job ASC , Salary DESC;
CREATE view viewG as select * from  Employee where salary > 40000;
 
ALTER table employee MODIFY Ename VARCHAR(40);
ALTER table employee add column Residence VARCHAR(50);
DESCRIBE employee;
insert into employee (EmpNo,Ename,Job)
values
('E010','Jane','teacher');
CREATE TABLE loction (
    p.o.box VARCHAR(10) PRIMARY KEY,
    Town VARCHAR(30),
    district VARCHAR(30),
    EmpNo VARCHAR(10) PRIMARY KEY,
    Foreign Key (EmpNo) REFERENCES (employee)
    
    
);

